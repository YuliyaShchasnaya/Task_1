# CustomValidator
Custom Validation Task for NET Padawans

Please fork this repository.
1)Implement methods of CustomValidator class by needed modifications and functionality.<br/>
2)Check Build and Run sample Unit tests.<br/>
3) Add your own Unit tests for all possible usage scenarious.  <br/>
4) Submit your solution using Padawans application.<br/>
5) See your Build and tests results.<br/>
6) Note, that you may Submit your solution not more than 2 times for every task<br/>
Good luck and Happy coding!
