﻿using System;
namespace CustomValidator
{
    public class IdentityValidator
    {
        public IdentityValidator()
        {
        }
        public bool Validate(string pwd)
        {
            throw new NotImplementedException();
        }
    }
}
